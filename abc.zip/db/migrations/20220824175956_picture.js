/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.createTable('picture', function (t) {
        t.increments('id').primary().defaultTo(1);
        t.string('image_url').defaultTo(null);
        t.timestamps(false, true);
    })
  
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.dropTableIfExists('picture');
};
