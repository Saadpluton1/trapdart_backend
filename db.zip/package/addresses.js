
const crowdsale_addr = "0xB1B24Dd24d7d0570FcF73188DeBC95f97b99f59e"
const trapDart_addr = "0xb243D6D872F7cFd7D77263534cB3474E0aaa462b"
const vesting_addr = "0xD7363a4a80eb8d01C1570b8C7dFaD8805cca5f2A"
const nFT_addr = "0x4c71c199216619a9c0F1FBc27E01A7275fc989E0"
const Vesting_dev_addr = "0x17C9b014a4c0B46CD11fde22cD17b26245341b1b"
const Vesting_treasury_addr = "0xe2920829591FC85Be9e8632f7ACEfcB0fB53CD3C"
const Vesting_founder_addr = "0x2fe2eA51243cc7836c6e7d2AE387f2F196E9D282"

module.exports = {crowdsale_addr , trapDart_addr }